﻿namespace tubesAKHIR_prima
{
    partial class ganti
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            password = new TextBox();
            label1 = new Label();
            passwordNew = new TextBox();
            label3 = new Label();
            save = new Button();
            button2 = new Button();
            alert = new Label();
            SuspendLayout();
            // 
            // password
            // 
            password.Location = new Point(311, 144);
            password.Name = "password";
            password.Size = new Size(260, 23);
            password.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(157, 147);
            label1.Name = "label1";
            label1.Size = new Size(98, 15);
            label1.TabIndex = 2;
            label1.Text = "Password Saat ini";
            // 
            // passwordNew
            // 
            passwordNew.Location = new Point(311, 197);
            passwordNew.Name = "passwordNew";
            passwordNew.Size = new Size(260, 23);
            passwordNew.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(157, 197);
            label3.Name = "label3";
            label3.Size = new Size(84, 15);
            label3.TabIndex = 5;
            label3.Text = "Password baru";
            label3.Click += label3_Click;
            // 
            // save
            // 
            save.ForeColor = SystemColors.ActiveCaptionText;
            save.Location = new Point(450, 265);
            save.Name = "save";
            save.Size = new Size(121, 39);
            save.TabIndex = 8;
            save.Text = "Save";
            save.UseVisualStyleBackColor = true;
            save.Click += button1_Click;
            // 
            // button2
            // 
            button2.ForeColor = SystemColors.ActiveCaptionText;
            button2.Location = new Point(311, 265);
            button2.Name = "button2";
            button2.Size = new Size(121, 39);
            button2.TabIndex = 9;
            button2.Text = "Back";
            button2.UseVisualStyleBackColor = true;
            // 
            // alert
            // 
            alert.AutoSize = true;
            alert.Location = new Point(414, 111);
            alert.Name = "alert";
            alert.Size = new Size(38, 15);
            alert.TabIndex = 10;
            alert.Text = "label2";
            // 
            // ganti
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(800, 450);
            Controls.Add(alert);
            Controls.Add(button2);
            Controls.Add(save);
            Controls.Add(label3);
            Controls.Add(passwordNew);
            Controls.Add(label1);
            Controls.Add(password);
            ForeColor = SystemColors.ButtonHighlight;
            Name = "ganti";
            Text = "ganti";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox password;
        private Label label1;
        private TextBox passwordNew;
        private Label label3;
        private Button save;
        private Button button2;
        private Label alert;
    }
}