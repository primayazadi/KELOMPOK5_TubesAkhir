﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tubesAKHIR_prima
{
    public partial class ganti : Form
    {
        public ganti()
        {
            InitializeComponent();
            alert.Text = "";
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string file = "Session.json";
            Users users = new Users();

            //load session json
            if (File.Exists(file))
            {
                string json = File.ReadAllText(file);
                users = JsonConvert.DeserializeObject<Users>(json);
            }

            // cek password sekarang
            if(!users.Password.Equals(password.Text))
            {
                alert.Text = "Password User Tidak Di Temukan !";
            }
            else
            {

                // update password baru ke session
                users.Password = passwordNew.Text;
                string filesession = "Session.json";
                string updatedJson = JsonConvert.SerializeObject(users);
                File.WriteAllText(filesession, updatedJson);


                // update password baru ke list user
                string fileuser = "user.json";
                List<Users> userList = new List<Users>();
                if (File.Exists(fileuser))
                {
                    string json = File.ReadAllText(fileuser);
                    userList = JsonConvert.DeserializeObject<List<Users>>(json);
                }
                foreach (var userrow in userList)
                {
                    if (userrow.Username.Equals(users.Username))
                    {
                        userrow.Password = passwordNew.Text;
                    }
                }
                string updatedJsonList = JsonConvert.SerializeObject(userList);
                File.WriteAllText(fileuser, updatedJsonList);


                alert.Text = "Password Berhasil Di Update";

            }
        }
    }
}
