﻿namespace tubesAKHIR_Kelompok5.Libs
{
    public class Item
    {
        public string tanggal
        {
            get; set;
        }

        public string nama
        {
            get; set;
        }
        public string harga
        {
            get; set;
        }
        public string jumlah
        {
            get; set;
        }
        public string username
        {
            get; set;
        }

        public string total
        {
            get; set;
        }
    }
}
